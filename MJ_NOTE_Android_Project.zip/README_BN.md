# MJ NOTE — Android starter project

এই প্রজেক্টে আছে:
- নোট তৈরি, এডিট, ডিলিট ও সার্চ
- লোকাল ডিভাইসে নোট সংরক্ষণ
- Google Play Billing-এর এককালীন পণ্য (coin pack) লোড/কেনার প্রাথমিক কোড
- ১,০০০ কয়েনে ৩০ দিনের Premium চালুর ডেমো
- Notes / Coin Store / Premium স্ক্রিন

## গুরুত্বপূর্ণ সতর্কতা

এটি একটি **starter/demo project**, production-ready payment system নয়। বর্তমান কোডে কয়েন ও Premium মেয়াদ ফোনের local storage-এ রাখা হয়। বাস্তব অর্থের অ্যাপে এটি নিরাপদ নয়, কারণ ব্যবহারকারী ডিভাইসের ডেটা পরিবর্তন করতে পারে বা purchase flow অপব্যবহার হতে পারে।

বাস্তব ব্যবহারকারীদের জন্য প্রকাশের আগে অবশ্যই:
1. একটি নিরাপদ backend/server তৈরি করতে হবে।
2. Google Play purchase token server-এ যাচাই করতে হবে (Google Play Developer API)।
3. একই purchase token যেন একাধিকবার কয়েন না দেয়, তা server-এ নিশ্চিত করতে হবে।
4. coin balance ও premium expiry server-side রাখতে হবে।
5. Play Console-এ `mj_coins_100`, `mj_coins_300`, `mj_coins_700`, `mj_coins_1500` নামে INAPP products তৈরি করতে হবে।
6. অ্যাপটি Play Console-এর internal testing track-এ আপলোড করে licensed tester account দিয়ে পরীক্ষা করতে হবে।

## Build করার জন্য

- Android Studio-তে এই folder খুলুন।
- JDK 17 ব্যবহার করুন।
- Gradle sync সম্পন্ন করুন।
- Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।

শুধু Android ফোন থাকলে এই প্রজেক্টের build করা কঠিন হতে পারে; কম্পিউটার বা cloud build workflow লাগতে পারে।

## Product IDs

- `mj_coins_100` — 100 coins
- `mj_coins_300` — 300 coins
- `mj_coins_700` — 700 coins
- `mj_coins_1500` — 1500 coins

Google Play-এ product ID একবার প্রকাশের পরে বদলানো ঝামেলার হতে পারে, তাই Play Console-এ একই ID হুবহু ব্যবহার করুন।

## App identity

- App name: MJ NOTE
- Application ID: `com.mjnote.app`
- Version: 1.0
