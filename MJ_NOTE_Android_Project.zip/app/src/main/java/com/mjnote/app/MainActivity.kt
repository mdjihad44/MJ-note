package com.mjnote.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.android.billingclient.api.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Note(
    val id: Long,
    val title: String,
    val body: String,
    val updatedAt: Long
)

private data class CoinPack(
    val productId: String,
    val title: String,
    val coins: Int,
    val fallbackPrice: String
)

class MainActivity : ComponentActivity(), PurchasesUpdatedListener {
    private lateinit var billingClient: BillingClient
    private var productDetails by mutableStateOf<Map<String, ProductDetails>>(emptyMap())
    private var billingMessage by mutableStateOf("Connect Google Play to load coin packs.")
    private var coinBalance by mutableIntStateOf(0)
    private var premiumUntil by mutableLongStateOf(0L)

    private val packs = listOf(
        CoinPack("mj_coins_100", "Starter", 100, "Google Play price"),
        CoinPack("mj_coins_300", "Silver", 300, "Google Play price"),
        CoinPack("mj_coins_700", "Gold", 700, "Google Play price"),
        CoinPack("mj_coins_1500", "Diamond", 1500, "Google Play price")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("mj_note", MODE_PRIVATE)
        coinBalance = prefs.getInt("coins", 0)
        premiumUntil = prefs.getLong("premium_until", 0L)

        billingClient = BillingClient.newBuilder(this)
            .setListener(this)
            .enablePendingPurchases(
                PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
            )
            .build()

        connectBilling()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MJNoteApp(
                        coins = coinBalance,
                        premiumUntil = premiumUntil,
                        packs = packs,
                        productDetails = productDetails,
                        billingMessage = billingMessage,
                        onBuyPack = { pack -> launchPurchase(pack) },
                        onSpendPremium = { activatePremium() }
                    )
                }
            }
        }
    }

    private fun connectBilling() {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProducts()
                    queryOwnedPurchases()
                } else {
                    billingMessage = "Google Play Billing unavailable: ${result.debugMessage}"
                }
            }
            override fun onBillingServiceDisconnected() {
                billingMessage = "Google Play connection lost. Please try again."
            }
        })
    }

    private fun queryProducts() {
        val productList = packs.map {
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it.productId)
                .setProductType(BillingClient.ProductType.INAPP)
                .build()
        }
        val params = QueryProductDetailsParams.newBuilder().setProductList(productList).build()
        billingClient.queryProductDetailsAsync(params) { result, queryResult ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                productDetails = queryResult.productDetailsList.associateBy { it.productId }
                billingMessage = if (productDetails.isEmpty()) {
                    "No products found. Create the product IDs in Play Console and install a Play test build."
                } else {
                    "Coin packs loaded from Google Play."
                }
            } else {
                billingMessage = "Could not load products: ${result.debugMessage}"
            }
        }
    }

    private fun launchPurchase(pack: CoinPack) {
        val details = productDetails[pack.productId]
        if (details == null) {
            billingMessage = "This coin pack is not available yet. Check Play Console product setup."
            return
        }
        val offer = details.oneTimePurchaseOfferDetails
        if (offer == null) {
            billingMessage = "Google Play did not return a price for this item."
            return
        }
        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(details)
            .build()
        val flowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productParams))
            .build()
        billingClient.launchBillingFlow(this, flowParams)
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            purchases.forEach { processPurchase(it) }
        } else if (result.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
            billingMessage = "Purchase cancelled."
        } else {
            billingMessage = "Purchase failed: ${result.debugMessage}"
        }
    }

    private fun queryOwnedPurchases() {
        billingClient.queryPurchasesAsync(
            QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()
        ) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                purchases.forEach { purchase ->
                    // Production apps must validate purchase tokens with a secure backend.
                    if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        processPurchase(purchase, grantCoins = false)
                    }
                }
            }
        }
    }

    private fun processPurchase(purchase: Purchase, grantCoins: Boolean = true) {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return
        val prefs = getSharedPreferences("mj_note", MODE_PRIVATE)
        val processed = prefs.getStringSet("processed_tokens", emptySet())!!.toMutableSet()
        val isNewPurchase = !processed.contains(purchase.purchaseToken)

        if (grantCoins && isNewPurchase) {
            val purchasedCoins = purchase.products.sumOf { productId ->
                packs.firstOrNull { it.productId == productId }?.coins ?: 0
            }
            if (purchasedCoins > 0) {
                coinBalance += purchasedCoins
                prefs.edit().putInt("coins", coinBalance).apply()
                processed.add(purchase.purchaseToken)
                prefs.edit().putStringSet("processed_tokens", processed).apply()
            }
        }

        if (!purchase.isAcknowledged) {
            val acknowledgeParams = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(purchase.purchaseToken)
                .build()
            billingClient.acknowledgePurchase(acknowledgeParams) { ackResult ->
                billingMessage = if (ackResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    "Purchase completed. Your coin balance has been updated."
                } else {
                    "Purchase acknowledgement pending: ${ackResult.debugMessage}"
                }
            }
        } else {
            billingMessage = "Purchase restored/checked."
        }
    }

    private fun activatePremium() {
        val cost = 1000
        if (coinBalance < cost) {
            billingMessage = "You need 1,000 coins to unlock 30-day Premium."
            return
        }
        val now = System.currentTimeMillis()
        val start = maxOf(now, premiumUntil)
        premiumUntil = start + 30L * 24 * 60 * 60 * 1000
        coinBalance -= cost
        getSharedPreferences("mj_note", MODE_PRIVATE).edit()
            .putInt("coins", coinBalance)
            .putLong("premium_until", premiumUntil)
            .apply()
        billingMessage = "Premium activated for 30 days."
    }

    override fun onDestroy() {
        if (::billingClient.isInitialized) billingClient.endConnection()
        super.onDestroy()
    }
}

@Composable
private fun MJNoteApp(
    coins: Int,
    premiumUntil: Long,
    packs: List<CoinPack>,
    productDetails: Map<String, ProductDetails>,
    billingMessage: String,
    onBuyPack: (CoinPack) -> Unit,
    onSpendPremium: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mj_note", ComponentActivity.MODE_PRIVATE) }
    var notes by remember { mutableStateOf(loadNotes(prefs.getString("notes_json", "[]") ?: "[]")) }
    var search by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf<Long?>(null) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }

    val premiumActive = premiumUntil > System.currentTimeMillis()
    val filteredNotes = notes.filter {
        it.title.contains(search, true) || it.body.contains(search, true)
    }

    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp)) {
                Text("MJ NOTE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(if (premiumActive) "👑 Premium active" else "Your notes, your space", color = MaterialTheme.colorScheme.primary)
            }
        },
        floatingActionButton = {
            if (tab == 0) FloatingActionButton(onClick = {
                editingId = null; title = ""; body = ""; showEditor = true
            }) { Icon(Icons.Default.Add, contentDescription = "Add note") }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("📝") }, label = { Text("Notes") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("🪙") }, label = { Text("Coin Store") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("👑") }, label = { Text("Premium") })
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (tab == 0) {
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    placeholder = { Text("Search notes") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true
                )
                if (filteredNotes.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(if (notes.isEmpty()) "Tap + to write your first note." else "No notes found.")
                    }
                } else {
                    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filteredNotes, key = { it.id }) { note ->
                            Card(Modifier.fillMaxWidth().clickable {
                                editingId = note.id; title = note.title; body = note.body; showEditor = true
                            }) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(note.title.ifBlank { "Untitled note" }, fontWeight = FontWeight.SemiBold)
                                        Spacer(Modifier.height(4.dp))
                                        Text(note.body, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                                        Text(formatDate(note.updatedAt), style = MaterialTheme.typography.labelSmall)
                                    }
                                    IconButton(onClick = {
                                        notes = notes.filterNot { it.id == note.id }
                                        saveNotes(prefs, notes)
                                    }) { Icon(Icons.Default.Delete, contentDescription = "Delete note") }
                                }
                            }
                        }
                    }
                }
            } else if (tab == 1) {
                Text("Buy coins with Google Play", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp))
                Text("Your balance: $coins coins", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp))
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(packs) { pack ->
                        val detail = productDetails[pack.productId]
                        val price = detail?.oneTimePurchaseOfferDetails?.formattedPrice ?: "Price in Google Play"
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(pack.title, fontWeight = FontWeight.Bold)
                                    Text("${pack.coins} coins")
                                    Text(price, color = MaterialTheme.colorScheme.primary)
                                    Text("Product ID: ${pack.productId}", style = MaterialTheme.typography.labelSmall)
                                }
                                Button(onClick = { onBuyPack(pack) }) { Text("Buy") }
                            }
                        }
                    }
                }
            } else {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("MJ NOTE Premium", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(if (premiumActive) "Premium until ${formatDate(premiumUntil)}" else "Unlock Premium for 30 days.")
                    Text("Cost: 1,000 coins")
                    Button(onClick = onSpendPremium, modifier = Modifier.fillMaxWidth()) {
                        Text(if (premiumActive) "Extend Premium by 30 days" else "Unlock 30-day Premium")
                    }
                    Text("Premium features planned: note lock, premium themes, PDF export and ad-free use.")
                }
            }
            if (billingMessage.isNotBlank()) {
                Text(billingMessage, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }
    }

    if (showEditor) {
        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editingId == null) "New note" else "Edit note") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Write your note") }, minLines = 4)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val now = System.currentTimeMillis()
                    val id = editingId ?: now
                    val updated = Note(id, title, body, now)
                    notes = if (editingId == null) listOf(updated) + notes else notes.map { if (it.id == id) updated else it }
                    saveNotes(prefs, notes)
                    showEditor = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text("Cancel") } }
        )
    }
}

private fun saveNotes(prefs: android.content.SharedPreferences, notes: List<Note>) {
    val array = JSONArray()
    notes.forEach {
        array.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("updatedAt", it.updatedAt))
    }
    prefs.edit().putString("notes_json", array.toString()).apply()
}

private fun loadNotes(json: String): List<Note> {
    return try {
        val array = JSONArray(json)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Note(o.optLong("id"), o.optString("title"), o.optString("body"), o.optLong("updatedAt"))
        }.sortedByDescending { it.updatedAt }
    } catch (_: Exception) { emptyList() }
}

private fun formatDate(timestamp: Long): String =
    SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(timestamp))
